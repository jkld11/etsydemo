class Listing < ActiveRecord::Base
end
